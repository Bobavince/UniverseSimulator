/**
 * @author Vincent F
 * Classe de test personnel (ne sera pas la classe final "main". Vous pouvez vous en servir pour tester vos classes.
 */
public class TestPerso {
	public static void main(String[] args) {
		new Affichage();
	}
}
