import java.util.LinkedList;
import javax.swing.*;
import java.awt.event.*;



public class EcouteurLancement implements ActionListener {
	
	FenetreAjout fen= new FenetreAjout();
	
	public EcouteurLancement(FenetreAjout fen){
		this.fen=fen;	
	}
	
	public void actionPerformed(ActionEvent ae) {
		//Particule maParticule= new Particule();//getteurs des autres ecouteurs;
		//listeparticule.add(maParticule) //liste en attributs de la fenetre
		//fen.dispose();
		
	}
}
