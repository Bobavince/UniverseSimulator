import java.util.LinkedList;

/**
 * @author Vincent F
 *
 */
public class ListeObjet {
	
	LinkedList<Particule> listeParticule = new LinkedList<Particule>();

	
	/** Constructeur
	 * @param listeParticule
	 */
	public ListeObjet() {

	}

	/**
	 * @return the listeParticule
	 */
	public LinkedList<Particule> getListeParticule() {
		
		return listeParticule;
	}
	
	/**
	 * @param particuleAJour
	 */
	public void setParticule(Particule particuleAJour){
		
	}
	
	

}
