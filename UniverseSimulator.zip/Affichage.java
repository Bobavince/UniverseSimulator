/**
 * @author Vincent F
 *
 */
public class Affichage {
	
	

}
