/**
 * @author Vincent F
 *
 */
public class Vecteur {
	double x;
	double y;
	double z;
	
	public Vecteur(double x, double y, double z){
		
	}
	
	/**
	 * @param scalaire
	 * @return
	 */
	public Vecteur multScalaire(double scalaire){
		Vecteur resultat = null;
		
		return resultat;
	}
	
	/**
	 * @param vect
	 * @return
	 */
	public double prodScalaire(Vecteur vect){
		double resultat = 0;

		return resultat;
	}
	
	/**
	 * @param vect
	 * @return
	 */
	public Vecteur addition(Vecteur vect){
		Vecteur resultat = null;

		return resultat;
	}
	
	/**
	 * @param vect
	 * @return
	 */
	public Vecteur soustraction(Vecteur vect){
		Vecteur resultat = null;

		return resultat;
	}

	/**
	 * @return
	 */
	public Vecteur normalise(){
		Vecteur resultat = null;

		return resultat;
	}
	
	/** Calculer le module d'un vecteur
	 * @return
	 */
	public double module(){
		double resultat = 0;

		return resultat;
	}
	
	/** Calculer le module au carr� (donc sans utiliser la racine) d'un vecteur
	 * @return
	 */
	public double moduleCarre(){
		double resultat = 0;

		return resultat;
	}
	
	/**
	 * @param vect
	 * @return
	 */
	public boolean equals(Vecteur vect) {
		boolean resultat = false;

		return resultat;
	}


}
