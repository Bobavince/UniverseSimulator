/**
 * @author Vincent F
 *
 */
public class Meteorite extends Particule{

	/** Constructeur
	 * @param x
	 * @param y
	 * @param z
	 * @param vx
	 * @param vy
	 * @param vz
	 * @param ax
	 * @param ay
	 * @param az
	 */
	public Meteorite(double x, double y, double z, double vx, double vy, double vz, double ax, double ay, double az) {
		super(x, y, z, vx, vy, vz, ax, ay, az);
		// TODO Auto-generated constructor stub
	}

}
