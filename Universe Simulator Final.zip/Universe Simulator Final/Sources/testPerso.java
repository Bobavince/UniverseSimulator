/** Classe conteant le main du programme
 */
public class testPerso {
	/** LE MAIN
	 * @param args : les arguments qu'on peut passer en ligne de commande au programme. Aucune influence. 
	 */
	public static void main(String[] args) {
		new Affichage();
	}
}